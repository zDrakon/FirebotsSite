ssh -i ./aws/default-aws-key-pair.pem ec2-user@54.191.229.128
