Setup
----

- Dependencies: `rvm`, `RubyGems`, `bundle`

- Sqlite3 database for local development

- Run tests via `guard`

- Setup via `bundle install`
