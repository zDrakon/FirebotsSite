## FRC 3501 robot vision (2014)

This uses OpenCV to detect the game ball (similar to a yoga ball), "hot goals" (strips of retroreflective tape), and opposing teams' bumpers.

Eventual goals:
- be able to follow a team's bumpers, keeping parallel to and a fixed distance from them at all times.
- be able to track a ball's movement and estimate its trajectory
